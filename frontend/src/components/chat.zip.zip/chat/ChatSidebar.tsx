import {
  Plus,
  MessageSquare,
  MessageCircle,
} from "lucide-react";

import { useConversations } from "@/hooks/useConversations";

interface ChatSidebarProps {
  selectedConversationId: string | null;
  onSelectConversation: (conversationId: string) => void;
  onNewChat: () => void;
}

export default function ChatSidebar({
  selectedConversationId,
  onSelectConversation,
  onNewChat,
}: ChatSidebarProps) {
  const {
    conversations,
    loading,
  } = useConversations();

  return (
    <aside
      className="
        flex h-full w-80 shrink-0 flex-col
        overflow-hidden
        border-r border-[#252b32]
        bg-[#101318]
      "
    >
      {/* ==========================================
          NEW CHAT
      ========================================== */}

      <div
        className="
          shrink-0
          border-b border-[#252b32]
          p-5
        "
      >
        <button
          type="button"
          onClick={onNewChat}
          className="
            group
            flex w-full
            items-center justify-center gap-2.5
            rounded-lg
            border border-[#343b43]
            bg-[#171b20]
            px-4 py-3
            text-sm font-medium
            text-primary
            transition-all duration-200
            hover:border-[#d4a72c]/50
            hover:bg-[#1b1f25]
          "
        >
          <Plus
            size={17}
            strokeWidth={2}
            className="
              text-[#d4a72c]
              transition-transform duration-200
              group-hover:rotate-90
            "
          />

          <span>
            New Conversation
          </span>
        </button>
      </div>

      {/* ==========================================
          CONVERSATION HISTORY
      ========================================== */}

      <div
        className="
          min-h-0 flex-1
          overflow-y-auto
          overflow-x-hidden
          px-4 py-5
        "
      >
        {/* Section Header */}

        <div className="mb-4 flex items-center justify-between px-2">

          <div className="flex items-center gap-2">

            <MessageCircle
              size={14}
              strokeWidth={1.8}
              className="text-muted"
            />

            <p
              className="
                text-[11px]
                font-semibold
                uppercase
                tracking-[0.16em]
                text-muted
              "
            >
              Conversations
            </p>

          </div>

          {conversations.length > 0 && (
            <span
              className="
                rounded-md
                border border-[#292f36]
                bg-[#171b20]
                px-1.5 py-0.5
                text-[10px]
                font-medium
                text-muted
              "
            >
              {conversations.length}
            </span>
          )}

        </div>

        {/* ==========================================
            LOADING
        ========================================== */}

        {loading && (
          <div className="space-y-2">

            {[1, 2, 3].map((item) => (
              <div
                key={item}
                className="
                  h-11
                  animate-pulse
                  rounded-lg
                  bg-[#171b20]
                "
              />
            ))}

          </div>
        )}

        {/* ==========================================
            EMPTY STATE
        ========================================== */}

        {!loading &&
          conversations.length === 0 && (
            <div
              className="
                mx-1
                rounded-lg
                border border-dashed
                border-[#2a3037]
                bg-[#14181d]
                px-4 py-6
                text-center
              "
            >
              <MessageSquare
                size={20}
                strokeWidth={1.5}
                className="
                  mx-auto mb-3
                  text-[#4d5661]
                "
              />

              <p className="text-sm text-secondary">
                No conversations yet
              </p>

              <p
                className="
                  mt-1
                  text-xs
                  leading-relaxed
                  text-[#56606b]
                "
              >
                Start a conversation to begin
                working with your engineering
                assistant.
              </p>
            </div>
          )}

        {/* ==========================================
            CONVERSATIONS
        ========================================== */}

        {!loading &&
          conversations.length > 0 && (
            <div className="space-y-1">

              {conversations.map((conversation) => {
                const isSelected =
                  conversation.id ===
                  selectedConversationId;

                return (
                  <button
                    type="button"
                    key={conversation.id}
                    onClick={() =>
                      onSelectConversation(
                        conversation.id
                      )
                    }
                    className={`
                      group
                      relative
                      flex w-full
                      min-w-0
                      items-center gap-3
                      rounded-lg
                      px-3 py-3
                      text-left
                      transition-all duration-150

                      ${
                        isSelected
                          ? `
                            border
                            border-[#3a3421]
                            bg-[#1b1c1b]
                            text-primary
                          `
                          : `
                            border border-transparent
                           text-secondary
                            hover:border-[#292f36]
                            hover:bg-[#171b20]
                            hover:text-primary
                          `
                      }
                    `}
                  >

                    {/* Active indicator */}

                    {isSelected && (
                      <span
                        className="
                          absolute
                          left-0
                          top-1/2
                          h-5
                          w-0.5
                          -translate-y-1/2
                          rounded-full
                          bg-[#d4a72c]
                        "
                      />
                    )}

                    {/* Conversation icon */}

                    <MessageSquare
                      size={16}
                      strokeWidth={1.8}
                      className={`
                        shrink-0
                        transition-colors

                        ${
                          isSelected
                            ? "text-[#d4a72c]"
                            : "text-[#59636e] group-hover:text-secondary"
                        }
                      `}
                    />

                    {/* Conversation title */}

                    <span
                      className="
                        min-w-0
                        flex-1
                        truncate
                        text-sm
                      "
                    >
                      {conversation.title}
                    </span>

                  </button>
                );
              })}

            </div>
          )}

      </div>

      {/* ==========================================
          SIDEBAR FOOTER
      ========================================== */}

      <div
        className="
          shrink-0
          border-t border-[#252b32]
          px-4 py-3
        "
      >
        <div
          className="
            flex items-center
            justify-between
            px-2
          "
        >
         

          <span
            className="
              text-[10px]
              text-[#4f5862]
            "
          >
            Engineering Chat
          </span>
        </div>
      </div>

    </aside>
  );
}
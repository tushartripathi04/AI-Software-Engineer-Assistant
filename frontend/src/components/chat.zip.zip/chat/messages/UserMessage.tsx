import type { ChatMessage } from "@/types/chat";

interface Props {
  message: ChatMessage;
}

export default function UserMessage({
  message,
}: Props) {
  return (
    <div className="flex justify-end px-2">
      <div
        className="
          max-w-2xl
          rounded-2xl
          border
          border-[#8a6a16]
          bg-[#171a1f]
          px-5
          py-3.5
          text-slate-100
          shadow-[0_4px_20px_rgba(0,0,0,0.18)]
        "
      >
        <p className="whitespace-pre-wrap text-[15px] leading-7">
          {message.content}
        </p>
      </div>
    </div>
  );
}
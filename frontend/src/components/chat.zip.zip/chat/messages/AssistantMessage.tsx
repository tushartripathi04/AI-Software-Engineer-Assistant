import { Bot } from "lucide-react";
import type { ChatMessage } from "@/types/chat";
import MarkdownRenderer from "../markdown/MarkdownRenderer";

interface Props {
  message: ChatMessage;
}

export default function AssistantMessage({
  message,
}: Props) {
  return (
    <div className="flex gap-4 px-2">
      {/* Assistant Identity */}
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#8a6a16] bg-[#15191e]">
        <Bot
          className="h-5 w-5 text-[#d4a72c]"
          strokeWidth={1.8}
        />
      </div>

      {/* Response Panel */}
      <div className="min-w-0 w-full max-w-5xl rounded-2xl border border-slate-800 bg-input px-6 py-5">
        {/* Response Header */}
        <div className="mb-4 flex items-center gap-2 border-b border-slate-800 pb-3">
          <span className="text-sm font-medium text-slate-200">
            Engineering Assistant
          </span>

          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />

          <span className="text-xs text-slate-500">
            Response
          </span>
        </div>

        {/* Markdown Content */}
        <div className="max-w-none text-[15px] leading-7 text-slate-300">
          <MarkdownRenderer content={message.content} />
        </div>
      </div>
    </div>
  );
}
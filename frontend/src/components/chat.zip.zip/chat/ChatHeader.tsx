import { Bot, Circle } from "lucide-react";

export default function ChatHeader() {
  return (
    <div className="flex h-20 shrink-0 items-center justify-between border-b border-slate-800 bg-[#0d1014] px-6">
      {/* Left */}
      <div className="flex items-center gap-3">
        {/* Assistant Icon */}
        <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-700 bg-[#15191e]">
          <Bot
            size={20}
            className="text-[#d4a72c]"
          />
        </div>

        {/* Title */}
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-slate-100">
              Engineering Assistant
            </h2>

            <Circle
              size={7}
              fill="currentColor"
              className="text-emerald-400"
            />
          </div>

          <p className="text-xs text-slate-500">
            AI-powered software engineering workspace
          </p>
        </div>
      </div>

      {/* Right — AI Engine */}
      <div className="flex items-center gap-2 rounded-lg border border-slate-700 bg-[#15191e] px-3 py-2">
        <Circle
          size={7}
          fill="currentColor"
          className="text-[#d4a72c]"
        />

        <span className="text-sm text-slate-400">
          Groq Engine
        </span>

        <span className="text-slate-600">
          ▾
        </span>
      </div>
    </div>
  );
}